//package in.sis.cqrs.readservice.service;
//
//import java.util.Map;
//
//import org.ektorp.DocumentNotFoundException;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//@Service
//public class DocumentServiceImpl implements DocumentServices {
//
//    @Autowired
//    private CouchDbClient couchDbClient;
//
//    @Override
//    public Map<String, Object> fetchDocument(String enquiryNumber) throws DocumentNotFoundException {
//        Map<String, Object> document = couchDbClient.find(Map.class, enquiryNumber);
//        if (document == null) {
//            throw new DocumentNotFoundException("Document not found for enquiry number: " + enquiryNumber);
//        }
//        return document;
//    }
//
//    @Override
//    public void updateDocument(Map<String, Object> document) throws DocumentNotFoundException {
//        String enquiryNumber = (String) document.get("_id");
//        if (enquiryNumber == null || !couchDbClient.contains(enquiryNumber)) {
//            throw new DocumentNotFoundException("Document not found for enquiry number: " + enquiryNumber);
//        }
//        couchDbClient.update(document);
//    }
//
//    @Override
//    public void createDocument(Map<String, Object> document) {
//        couchDbClient.save(document);
//    }
//}
