//package in.sis.cqrs.readservice.entity;
//
//import org.ektorp.support.TypeDiscriminator;
//import org.springframework.data.annotation.Id;
//import lombok.Data;
//
//@TypeDiscriminator("doc.type == 'EnquiryView'")
//@Data
//public class CouchdbEnquiryView {
//
//	@Id
//    private String id; 
//    private String type = "EnquiryView";
//    private String companyCode;
//    private String saveind;
//    private String enqDecisionIndIndicator;
//    private String gps_enabled_ind;
//    private String mobileNo;
//    private String transferDate;
//    private String userId;
//    private String uuid;
//    private String version;
//    private String inputDate;
//    private String compCode;
//    private String environmentInd;
//    private String latlang;
//    private String imeiNo;
//    private LeadInputsDetails leadInputsDetails;
//    private String imei;
//    private String fileIndicator;
//    private String mainApplicantIndicator;
//    private String simNo;
//    private String modeInd;
//    private String leadId;
//
//    @Data
//    public static class LeadInputsDetails {
//        private ContractDetails contract_details;
//        private EnquiryNumber enquiry_number;
//        private LeadDetails[] lead_details;
//
//        public ContractDetails getContract_details() {
//            return contract_details;
//        }
//
//        public void setContract_details(ContractDetails contract_details) {
//            this.contract_details = contract_details;
//        }
//
//        public EnquiryNumber getEnquiry_number() {
//            return enquiry_number;
//        }
//
//        public void setEnquiry_number(EnquiryNumber enquiry_number) {
//            this.enquiry_number = enquiry_number;
//        }
//
//        public LeadDetails[] getLead_details() {
//            return lead_details;
//        }
//
//        public void setLead_details(LeadDetails[] lead_details) {
//            this.lead_details = lead_details;
//        }
//    }
//
//    // Nested classes for contract details and lead details
//    @Data
//    public static class ContractDetails {
//        private String business_source;
//        private String contract_type;
//        private String asset_make;
//        private String asset_type;
//        private String asset_class_code;
//        private String asset_cost;
//        private String loan_tenure;
//        private String asset_model;
//        private String amount_finance;
//        private String dealer_code;
//        private String dealer_name;
//        private String dealer_address;
//        private String units;
//        private String remarks;
//        private String loan_purpose;
//        private String assesment_criteria;
//        private String empl_business_years;
//        private String net_income;
//        private String asset_usage_code;
//        private String exp_in_years;
//        private String irr_quoted_to_customer;
//        private String residence_pincode;
//        private String residence_location_id;
//        private String location_stable_years;
//        private String appraisal_categ_code;
//        private String marketing_employee_code;
//        private String fuel_type_code;
//        private String exp_trac_ownshp;
//        private String trac_ownshp_yrs;
//        private String ownshp_reg_no;
//        private String land_holdgs;
//        private String agri_ind;
//        private String trac_repay_freq;
//        private String horse_power;
//        private String product_model;
//    }
//
//    public static class EnquiryNumber {
//        private String enquiry_number;
//
//        public String getEnquiry_number() {
//            return enquiry_number;
//        }
//
//        public void setEnquiry_number(String enquiry_number) {
//            this.enquiry_number = enquiry_number;
//        }
//    }
//    @Data
//    public static class LeadDetails {
//        private String alt_mobile_number;
//        private String title;
//        private String email_id;
//        private String constitution;
//        private String gender;
//        private String name;
//        private String initial_name;
//        private String middle_name;
//        private String last_name;
//        private String dob;
//        private String address1;
//        private String address2;
//        private String address3;
//        private String pincode;
//        private String pan_number;
//        private String voter_id;
//        private String driving_licence;
//        private String passport;
//        private String aadhar_number;
//        private String phone_number;
//        private String mobile_number;
//        private String form_type;
//        private String form_count;
//        private String qr_checked;
//        private String location_id;
//        private String location_name;
//        private String state_name;
//        private String district;
//        private String occupation_type;
//        private String customer_code;
//        private String ckyc_ind;
//        private String ckyc_no;
//        private String dan_value;
//        private String business;
//        private String pref_language_code;
//        private String form_code;
//        private String customer_class_code;
//        private String residential_type;
//        private String passport_valid_date;
//        private String sms_o_ind;
//        private String kyc_verify_ind;
//        private String applicant_status;
//        private String sms_ind;
//        private String cust_conf_ind;
//        private String enq_decision_ind;
//    }
//}
//
