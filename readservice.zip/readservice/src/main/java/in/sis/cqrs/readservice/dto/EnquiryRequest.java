package in.sis.cqrs.readservice.dto;

import lombok.Data;

@Data
public class EnquiryRequest {

	private String imei;
    private String employeeId;
    private String userId;
    private String uuid;
    private String version;
    private String enquiryNumber;
}
