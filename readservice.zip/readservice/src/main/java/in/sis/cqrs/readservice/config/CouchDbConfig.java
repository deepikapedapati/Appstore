//package in.sis.cqrs.readservice.config;
//
//import org.ektorp.CouchDbConnector;
//import org.ektorp.http.HttpClient;
//import org.ektorp.http.StdHttpClient;
//import org.ektorp.impl.StdCouchDbInstance;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//public class CouchDbConfig {
//
//    @Bean
//    public CouchDbConnector couchDbConnector() throws Exception {
//        HttpClient httpClient = new StdHttpClient.Builder()
//                .url("http://10.133.0.33:5984/_utils/#/_all_dbs")
//                .username("sdsusr") 
//                .password("sdsusr123")
//                .build();
//
//        StdCouchDbInstance dbInstance = new StdCouchDbInstance(httpClient);
//        return dbInstance.createConnector("sdsdba", true); 
//    }
//}
