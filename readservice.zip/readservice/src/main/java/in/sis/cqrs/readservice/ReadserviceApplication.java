package in.sis.cqrs.readservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReadserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReadserviceApplication.class, args);
		System.out.println("Readservice Connected");
	}

}
