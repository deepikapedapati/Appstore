package in.sis.cqrs.readservice.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;
import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"companyCode", "saveind", "enqDecisionIndIndicator", "gps_enabled_ind", "mobileNo", "transferDate", 
                    "userId", "uuid", "version", "inputDate", "compCode", "environmentInd", "latlang", "imeiNo", 
                    "leadInputsDetails", "imei", "fileIndicator", "mainApplicantIndicator", "simNo", "modeInd", "leadId"})
public class InputDetails {

	 private String companyCode;
	    private String saveind;
	    private String enqDecisionIndIndicator;
	    private String gps_enabled_ind;
	    private String mobileNo;
	    
	    @JsonFormat(pattern = "dd/MM/yyyy")
	    private String transferDate;

	    private String userId;
	    private String uuid;
	    private String version;

	    @JsonFormat(pattern = "dd/MM/yyyy")
	    private String inputDate;

	    private String compCode;
	    private String environmentInd;
	    private String latlang;
	    private String imeiNo;
	    private String imei;
	    private String fileIndicator;
	    private String mainApplicantIndicator;
	    private String simNo;
	    private String modeInd;
	    private String leadId;
	    private LeadInputsDetails leadInputsDetails;

	    @Data
	    public static class LeadInputsDetails {
	        @JsonProperty("contract_details")  
	        private ContractDetails contractDetails;
	        
	        @JsonProperty("enquiry_number")
	        private EnquiryNumber enquiryNumber;
	        
	        @JsonProperty("lead_details")
	        private List<LeadDetails> leadDetails;

	        @Data
	        public static class ContractDetails {
	            
	            @JsonProperty("BUSINESS_SOURCE")  
	            private String businessSource;
	            
	            @JsonProperty("CONTRACT_TYPE")  
	            private String contractType;
	            
	            @JsonProperty("ASSET_MAKE") 
	            private String assetMake;
	            
	            @JsonProperty("ASSET_TYPE") 
	            private String assetType;
	            
	            @JsonProperty("ASSET_CLASS_CODE")  
	            private String assetClassCode;
	            
	            @JsonProperty("ASSET_COST")  
	            private String assetCost;
	            
	            @JsonProperty("LOAN_TENURE")  
	            private String loanTenure;
	            
	            @JsonProperty("ASSET_MODEL") 
	            private String assetModel;
	            
	            @JsonProperty("AMOUNT_FINANCE")  
	            private String amountFinance;
	            
	            @JsonProperty("DEALER_CODE")  
	            private String dealerCode;
	            
	            @JsonProperty("DEALER_NAME")  
	            private String dealerName;
	            
	            @JsonProperty("DEALER_ADDRESS")  
	            private String dealerAddress;
	            
	            @JsonProperty("UNITS")
	            private String units;
	            
	            @JsonProperty("REMARKS")
	            private String remarks;
	            
	            @JsonProperty("LOAN_PURPOSE")  
	            private String loanPurpose;
	            
	            @JsonProperty("ASSESMENT_CRITERIA")  
	            private String assessmentCriteria;
	            
	            @JsonProperty("EMPL_BUSINESS_YEARS")  
	            private String emplBusinessYears;
	            
	            @JsonProperty("NET_INCOME")  
	            private String netIncome;
	            
	            @JsonProperty("ASSET_USAGE_CODE")  
	            private String assetUsageCode;
	            
	            @JsonProperty("EXP_IN_YEARS")  
	            private String expInYears;
	            
	            @JsonProperty("IRR_QUOTED_TO_CUSTOMER")   
	            private String irrQuotedToCustomer;
	            
	            @JsonProperty("RESIDENCE_PINCODE")  
	            private String residencePincode;
	            
	            @JsonProperty("RESIDENCE_LOCATION_ID")  
	            private String residenceLocationId;
	            
	            @JsonProperty("LOCATION_STABLE_YEARS")  
	            private String locationStableYears;
	            
	            @JsonProperty("APPRAISAL_CATEG_CODE")  
	            private String appraisalCategCode;
	            
	            @JsonProperty("MARKETING_EMPLOYEE_CODE")  
	            private String marketingEmployeeCode;
	            
	            @JsonProperty("FUEL_TYPE_CODE")  
	            private String fuelTypeCode;
	            
	            @JsonProperty("EXP_TRAC_OWNSHP")  
	            private String expTracOwnshp;
	            
	            @JsonProperty("TRAC_OWNSHP_YRS")  
	            private String tracOwnshpYrs;
	            
	            @JsonProperty("OWNSHP_REG_NO")  
	            private String ownshpRegNo;
	            
	            @JsonProperty("LAND_HOLDGS")  
	            private String landHoldgs;
	            
	            @JsonProperty("AGRI_IND")  
	            private String agriInd;
	            
	            @JsonProperty("TRAC_REPAY_FREQ")  
	            private String tracRepayFreq;
	            
	            @JsonProperty("HORSE_POWER")  
	            private String horsePower;
	            
	            @JsonProperty("PRODUCT_MODEL")  
	            private String productModel;
	        }

	        @Data
	        public static class EnquiryNumber {
	            @JsonProperty("enquiry_number")
	            private String enquiryNumber;
	        }

	        @Data
	        public static class LeadDetails {
	            @JsonProperty("ALT_MOBILE_NUMBER")
	            private String altMobileNumber;
	            @JsonProperty("TITLE")
	            private String title;
	            @JsonProperty("EMAIL_ID")
	            private String emailId;
	            @JsonProperty("CONSTITUTION")
	            private String constitution;
	            @JsonProperty("GENDER")
	            private String gender;
	            @JsonProperty("NAME")
	            private String name;
	            @JsonProperty("INITIAL_NAME")
	            private String initialName;
	            @JsonProperty("MIDDLE_NAME")
	            private String middleName;
	            @JsonProperty("LAST_NAME")
	            private String lastName;
	            @JsonProperty("DOB")
	            private String dob;
	            @JsonProperty("ADDRESS1")
	            private String address1;
	            @JsonProperty("ADDRESS2")
	            private String address2;
	            @JsonProperty("ADDRESS3")
	            private String address3;
	            @JsonProperty("PINCODE")
	            private String pincode;
	            @JsonProperty("PAN_NUMBER")
	            private String panNumber;
	            @JsonProperty("VOTER_ID")
	            private String voterId;
	            @JsonProperty("DRIVING_LICENCE")
	            private String drivingLicence;
	            @JsonProperty("PASSPORT")
	            private String passport;
	            @JsonProperty("AADHAR_NUMBER")
	            private String aadharNumber;
	            @JsonProperty("PHONE_NUMBER")
	            private String phoneNumber;
	            @JsonProperty("MOBILE_NUMBER")
	            private String mobileNumber;
	            @JsonProperty("FORM_TYPE")
	            private String formType;
	            @JsonProperty("FORM_COUNT")
	            private int formCount;
	            @JsonProperty("QR_CHECKED")
	            private String qrChecked;
	            @JsonProperty("LOCATION_ID")
	            private String locationId;
	            @JsonProperty("LOCATION_NAME")
	            private String locationName;
	            @JsonProperty("STATE_NAME")
	            private String stateName;
	            @JsonProperty("DISTRICT")
	            private String district;
	            @JsonProperty("OCCUPATION_TYPE")
	            private String occupationType;
	            @JsonProperty("CUSTOMER_CODE")
	            private String customerCode;
	            @JsonProperty("CKYC_IND")
	            private String ckycInd;
	            @JsonProperty("CKYC_NO")
	            private String ckycNo;
	            @JsonProperty("DAN_VALUE")
	            private String danValue;
	            @JsonProperty("BUSINESS")
	            private String business;
	            @JsonProperty("PREF_LANGUAGE_CODE")
	            private String prefLanguageCode;
	            @JsonProperty("FORM_CODE")
	            private String formCode;
	            @JsonProperty("CUSTOMER_CLASS_CODE")
	            private String customerClassCode;
	            @JsonProperty("RESIDENTIAL_TYPE")
	            private String residentialType;
	            @JsonProperty("PASSPORT_VALID_DATE")
	            private String passportValidDate;
	            @JsonProperty("SMS_O_IND")
	            private String smsOInd;
	            @JsonProperty("KYC_VERIFY_IND")
	            private String kycVerifyInd;
	            @JsonProperty("APPLICANT_STATUS")
	            private String applicantStatus;
	            @JsonProperty("SMS_IND")
	            private String smsInd;
	            @JsonProperty("CUST_CONF_IND")
	            private String custConfInd;
	            @JsonProperty("ENQ_DECISION_IND")
	            private String enqDecisionInd;
	        }
	    }
	}


//package in.sis.cqrs.readservice.dto;
//
//import com.fasterxml.jackson.annotation.JsonFormat;
//import com.fasterxml.jackson.annotation.JsonInclude;
//import com.fasterxml.jackson.annotation.JsonPropertyOrder;
//import lombok.Data;
//import java.time.LocalDate;
//import java.util.List;
//
//@Data
//@JsonInclude(JsonInclude.Include.NON_NULL)
//@JsonPropertyOrder({"companyCode", "saveind", "enqDecisionIndIndicator", "gps_enabled_ind", "mobileNo", "transferDate", 
//                    "userId", "uuid", "version", "inputDate", "compCode", "environmentInd", "latlang", "imeiNo", 
//                    "leadInputsDetails", "imei", "fileIndicator", "mainApplicantIndicator", "simNo", "modeInd", "leadId"})
//public class InputDetails {
//
//    private String companyCode;
//    private String saveind;
//    private String enqDecisionIndIndicator;
//    private String gps_enabled_ind;
//    private String mobileNo;
//    @JsonFormat(pattern = "dd/MM/yyyy")
//    private LocalDate transferDate;
//    private String userId;
//    private String uuid;
//    private String version;
//    @JsonFormat(pattern = "dd/MM/yyyy")
//    private LocalDate inputDate;
//    private String compCode;
//    private String environmentInd;
//    private String latlang;
//    private String imeiNo;
//    private String imei;
//    private String fileIndicator;
//    private String mainApplicantIndicator;
//    private String simNo;
//    private String modeInd;
//    private String leadId;
//    private LeadInputsDetails leadInputsDetails;
//
//    @Data
//    public static class LeadInputsDetails {
//        private ContractDetails contract_details;
//        private EnquiryNumber enquiry_number;
//        private List<LeadDetails> lead_details;
//
//        @Data
//        public static class ContractDetails {
//            private String business_source;
//            private String contract_type;
//            private String asset_make;
//            private String asset_type;
//            private String asset_class_code;
//            private String asset_Cost;
//            private String loan_tenure;
//            private String asset_model;
//            private String amount_finance;
//            private String dealer_code;
//            private String dealer_name;
//            private String dealer_address;
//            private String units;
//            private String remarks;
//            private String loan_purpose;
//            private String assesment_criteria;
//            private String empl_business_years;
//            private String net_income;
//            private String asset_usage_code;
//            private String exp_in_years;
//            private String irr_quoted_to_customer;
//            private String residence_pincode;
//            private String residence_location_id;
//            private String location_stable_years;
//            private String appraisal_categ_code;
//            private String marketing_employee_code;
//            private String fuel_type_code;
//            private String exp_trac_ownshp;
//            private String trac_ownshp_yrs;
//            private String ownshp_reg_no;
//            private String land_holdgs;
//            private String agri_ind;
//            private String trac_repay_freq;
//            private String horse_power;
//            private String product_model;
//        }
//
//        @Data
//        public static class EnquiryNumber {
//            private String enquiry_number;
//        }
//
//        @Data
//        public static class LeadDetails {
//            private String alt_mobile_number;
//            private String title;
//            private String email_id;
//            private String constitution;
//            private String gender;
//            private String name;
//            private String initial_name;
//            private String middle_name;
//            private String last_name;
//            private String dob;
//            private String address1;
//            private String address2;
//            private String address3;
//            private String pincode;
//            private String pan_number;
//            private String voter_id;
//            private String driving_licence;
//            private String passport;
//            private String aadhar_number;
//            private String phone_number;
//            private String mobile_number;
//            private String form_type;
//            private int form_count;
//            private String qr_checked;
//            private String location_id;
//            private String location_name;
//            private String state_name;
//            private String district;
//            private String occupation_type;
//            private String customer_code;
//            private String ckyc_ind;
//            private String ckyc_no;
//            private String dan_value;
//            private String business;
//            private String pref_language_code;
//            private String form_code;
//            private String customer_class_code;
//            private String residential_type;
//            private String passport_valid_date;
//            private String sms_o_ind;
//            private String kyc_verify_ind;
//            private String applicant_status;
//            private String sms_ind;
//            private String cust_conf_ind;
//            private String enq_decision_ind;
//        }
//    }
//}



//package in.sis.cqrs.writeservice.dto;
//
//import java.util.List;
//
//import com.fasterxml.jackson.annotation.JsonInclude;
//import com.fasterxml.jackson.annotation.JsonPropertyOrder;
//
//import lombok.Data;
//
//@Data
//@JsonInclude(JsonInclude.Include.NON_NULL) 
//@JsonPropertyOrder({"contract_details", "enquiry_number", "lead_details"})
//public class RequestDTO {
//	
//	private ContractDetails contract_details;
//    private EnquiryNumber enquiry_number;
//    private List<LeadDetails> lead_details;
//    
//    @Data
//    public static class ContractDetails {
//        private String business_source;
//        private String contract_type;
//        private String asset_make;
//        private String asset_type;
//        private String asset_class_code;
//        private String asset_Cost;
//        private String loan_tenure;
//        private String asset_model;
//        private String amount_finance;
//        private String dealer_code;
//        private String dealer_name;
//        private String dealer_address;
//        private String units;
//        private String remarks;
//        private String loan_purpose;
//        private String assesment_criteria;
//        private String empl_business_years;
//        private String Net_Income;
//        private String asset_usage_code;
//        private String exp_in_years;
//        private String irr_quoted_to_customer;
//        private String residence_pincode;
//        private String Residence_Location_Id;
//        private String location_stable_years;
//        private String appraisal_categ_code;
//        private String marketing_employee_code;
//        private String fuel_type_code;
//        private String exp_trac_ownshp;
//        private String trac_ownshp_yrs;
//        private String ownshp_reg_no;
//        private String land_holdgs;
//        private String agri_ind;
//        private String trac_repay_freq;
//        private String Horse_Power;
//        private String product_model;
//    }
//
//    @Data
//    public static class EnquiryNumber {
//        private String enquiry_number;
//    }
//
//    @Data
//    public static class LeadDetails {
//        private String alt_mobile_number;
//        private String title;
//        private String email_id;
//        private String constitution;
//        private String gender;
//        private String name;
//        private String initial_name;
//        private String middle_name;
//        private String last_name;
//        private String dob;
//        private String address1;
//        private String address2;
//        private String address3;
//        private String pincode;
//        private String pan_number;
//        private String voter_id;
//        private String driving_licence;
//        private String passport;
//        private String aadhar_number;
//        private String phone_number;
//        private String mobile_number;
//        private String form_type;
//        private int form_count;
//        private String qr_checked;
//        private String location_id;
//        private String location_name;
//        private String state_name;
//        private String district;
//        private String occupation_type;
//        private String customer_code;
//        private String Ckyc_Ind;
//        private String ckyc_no;
//        private String dan_value;
//        private String business;
//        private String pref_language_code;
//        private String form_code;
//        private String customer_class_code;
//        private String residential_type;
//        private String passport_valid_date;
//        private String sms_o_ind;
//        private String kyc_verify_ind;
//        private String applicant_status;
//        private String sms_ind;
//        private String cust_conf_ind;
//        private String enq_decision_ind;
//    }
//
//}

