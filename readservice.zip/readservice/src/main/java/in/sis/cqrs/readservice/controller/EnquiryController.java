package in.sis.cqrs.readservice.controller;

import org.ektorp.DocumentNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import in.sis.cqrs.readservice.service.DocumentService;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class EnquiryController {

	@Autowired
	private DocumentService documentService;

	@PostMapping("/v1/enquiriesfetch")
	public ResponseEntity<?> fetchEnquiryDetails(@RequestBody Map<String, String> request) {
		String enquiryNumber = request.get("enquiryNumber");
		if (enquiryNumber == null || enquiryNumber.isEmpty()) {
			return ResponseEntity.badRequest().body("Enquiry number is required.");
		}
		try {
			Map<String, Object> document = documentService.fetchDocument(enquiryNumber);
			return ResponseEntity.ok(document);
		} catch (DocumentNotFoundException e) {
			return ResponseEntity.status(404).body("No document found for enquiry number: " + enquiryNumber);
		} catch (Exception e) {
			return ResponseEntity.status(500).body("An error occurred: " + e.getMessage());
		}
	}
}


//package in.sis.cqrs.readservice.controller;
//
//import org.ektorp.DocumentNotFoundException;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//import in.sis.cqrs.readservice.service.DocumentService;
//
//import java.util.HashMap;
//import java.util.Map;
//
//@RestController
//@RequestMapping("/api")
//public class EnquiryController {
//
//    @Autowired
//    private DocumentService documentService;
//
//    @PostMapping("/v1/enquiriesfetch")
//    public ResponseEntity<?> fetchEnquiryDetails(
//            @RequestParam("imei") String imei,
//            @RequestParam("employeeId") String employeeId,
//            @RequestParam("userId") String userId,
//            @RequestParam("uuid") String uuid,
//            @RequestParam("version") String version,
//            @RequestParam("enquiryNumber") String enquiryNumber
//    ) {
//
//        if (enquiryNumber == null || enquiryNumber.isEmpty()) {
//            return ResponseEntity.badRequest().body("Enquiry number is required.");
//        }
//
//        try {
//            Map<String, Object> document = documentService.fetchDocument(enquiryNumber);
//
//            if (document == null || document.isEmpty()) {
//                return ResponseEntity.status(404).body("No document found for enquiry number: " + enquiryNumber);
//            }
//            Map<String, Object> response = formatResponse(document);
//            
//            return ResponseEntity.ok(response);
//
//        } catch (DocumentNotFoundException e) {
//            return ResponseEntity.status(404).body("No document found for enquiry number: " + enquiryNumber);
//        } catch (Exception e) {
//            return ResponseEntity.status(500).body("An error occurred: " + e.getMessage());
//        }
//    }
//
//    private Map<String, Object> formatResponse(Map<String, Object> document) {
//        // Format the document into the required response structure
//        Map<String, Object> response = new HashMap<>();
//        
//        // Set status and message
//        response.put("status", "1");
//        response.put("message", "Success");
//
//        // Set the document as query
//        response.put("query", document);
//
//        // Add other fields as required (example: image_upload, lmc_applicability)
//        response.put("image_upload", "Image Upload");
//        response.put("lmc_applicability", "Image Setup");
//
//        return response;
//    }
//}

