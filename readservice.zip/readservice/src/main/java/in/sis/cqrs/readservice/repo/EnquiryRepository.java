//package in.sis.cqrs.readservice.repo;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//import in.sis.cqrs.readservice.entity.CouchdbEnquiryView;
//
//public interface EnquiryRepository  extends JpaRepository<CouchdbEnquiryView, String> {
//    
//}
