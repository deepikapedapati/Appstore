////package in.sis.cqrs.readservice.config;
////
////import java.text.SimpleDateFormat;
////import java.time.Duration;
////import java.util.Calendar;
////import java.util.Map;
////import org.apache.kafka.clients.consumer.ConsumerConfig;
////import org.apache.kafka.common.serialization.StringDeserializer;
////import org.springframework.beans.factory.annotation.Autowired;
////import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
////import org.springframework.context.annotation.Bean;
////import org.springframework.context.annotation.Configuration;
////import org.springframework.kafka.annotation.EnableKafka;
////import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
////import org.springframework.kafka.core.ConsumerFactory;
////import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
////import org.springframework.kafka.support.serializer.JsonDeserializer;
////
////@EnableKafka
////@Configuration
////public class KafkaConsumerConfig {
////
////	private static final String bootstrapServers = "sfltstka.sfl-sis.sfl.ad:9092"; // sfltstka.sfl-sis.sfl.ad:9092
////	private static final String groupId = "querymodel_group_"; //querymodel_group_
////	private static final String autoOffsetReset = "latest";
////
////	@Autowired
////	private KafkaProperties kafkaProperties;
////
////	@Bean
////	ConcurrentKafkaListenerContainerFactory<String, Object> kafkaListenerContainerFactory() {
////		ConcurrentKafkaListenerContainerFactory<String, Object> factory = new ConcurrentKafkaListenerContainerFactory<>();
////		factory.setConsumerFactory(consumerFactory());
////		factory.setContainerCustomizer(
////				container -> container.getContainerProperties().setAuthExceptionRetryInterval(Duration.ofMinutes(10L)));
////		return factory;
////	}
////
////	@Bean
////	public ConsumerFactory<String, Object> consumerFactory() {
////
////		Map<String, Object> props = kafkaProperties.buildConsumerProperties();
////		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
////		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy-HH");
////		String formattedDate = sdf.format(Calendar.getInstance().getTime());
////		props.put(ConsumerConfig.GROUP_ID_CONFIG, groupId.concat(formattedDate));
////		props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
////		props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
////		props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, autoOffsetReset);
////
////		return new DefaultKafkaConsumerFactory<>(props, new StringDeserializer(), new JsonDeserializer<>(Object.class));
////	}
////}
//
//package in.sis.cqrs.readservice.config;
//
//import java.text.SimpleDateFormat;
//import java.time.Duration;
//import java.util.Calendar;
//import java.util.Map;
//import org.apache.kafka.clients.consumer.ConsumerConfig;
//import org.apache.kafka.common.serialization.StringDeserializer;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.kafka.annotation.EnableKafka;
//import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
//import org.springframework.kafka.core.ConsumerFactory;
//import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
//import org.springframework.kafka.listener.DefaultErrorHandler;
//import org.springframework.kafka.support.serializer.JsonDeserializer;
//import org.springframework.util.backoff.FixedBackOff;
//
//@EnableKafka
//@Configuration
//public class KafkaConsumerConfig {
//
//    private static final String bootstrapServers = "sfltstka.sfl-sis.sfl.ad:9092";
//    private static final String groupId = "querymodel_group_";
//    private static final String autoOffsetReset = "latest";
//
//    @Autowired
//    private KafkaProperties kafkaProperties;
//
//    @Bean
//    public ConcurrentKafkaListenerContainerFactory<String, Object> kafkaListenerContainerFactory() {
//        ConcurrentKafkaListenerContainerFactory<String, Object> factory = 
//            new ConcurrentKafkaListenerContainerFactory<>();
//        factory.setConsumerFactory(consumerFactory());
//        
//        factory.setCommonErrorHandler(new DefaultErrorHandler(
//            new FixedBackOff(1000L, 2)
//        ));
//        
//        factory.setContainerCustomizer(
//            container -> container.getContainerProperties().setAuthExceptionRetryInterval(Duration.ofMinutes(10L))
//        );
//        
//        return factory;
//    }
//
//    @Bean
//    public ConsumerFactory<String, Object> consumerFactory() {
//        Map<String, Object> props = kafkaProperties.buildConsumerProperties();
//        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
//        
//        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy-HH");
//        String formattedDate = sdf.format(Calendar.getInstance().getTime());
//        props.put(ConsumerConfig.GROUP_ID_CONFIG, groupId.concat(formattedDate));
//        
//        JsonDeserializer<Object> jsonDeserializer = new JsonDeserializer<>(Object.class);
//        jsonDeserializer.setUseTypeMapperForKey(true);
//        jsonDeserializer.addTrustedPackages("*");
//
//        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
//        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
//        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, autoOffsetReset);
//
//        return new DefaultKafkaConsumerFactory<>(props, new StringDeserializer(), jsonDeserializer);
//    }
//}