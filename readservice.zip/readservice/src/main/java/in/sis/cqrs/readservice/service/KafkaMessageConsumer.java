package in.sis.cqrs.readservice.service;

import java.util.HashMap;
import java.util.Map;
import org.ektorp.DocumentNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class KafkaMessageConsumer {
    @Autowired
    private ObjectMapper mapper;

    @Autowired
    private DocumentService documentService;

    @KafkaListener(topics = "loan-enquiry-topic", groupId = "querymodel_group_")
    public void listen(String message) {
        try {
            System.out.println("Received Kafka message: " + message);
            JsonNode rootNode = mapper.readTree(message);
            
            JsonNode leadInputsDetails = rootNode.path("data")
                                                .path("leadInputsDetails");
            String enquiryNumber = leadInputsDetails.path("enquiry_number")
                                                   .path("enquiry_number")
                                                   .asText();
            
            if (enquiryNumber == null || enquiryNumber.isEmpty()) {
                System.out.println("Invalid enquiry number received in message.");
                return;
            }
            processEnquiryDocument(enquiryNumber, rootNode);
        } catch (Exception e) {
            System.err.println("Error processing message: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void processEnquiryDocument(String enquiryNumber, JsonNode rootNode) {
        Map<String, Object> tempIdenDoc;
        try {
            tempIdenDoc = documentService.fetchDocument(enquiryNumber);
            
            if (tempIdenDoc == null || tempIdenDoc.isEmpty()) {
                System.out.println("Document is empty or not found for enquiry number: " + enquiryNumber);
            } else {
                System.out.println("Document contents for enquiry number: " + enquiryNumber + " -> " + tempIdenDoc);
            }
            
            tempIdenDoc.put("dtls", rootNode);
            documentService.updateDocument(tempIdenDoc);
            System.out.println("Document updated successfully for enquiry number: " + enquiryNumber);
        } catch (DocumentNotFoundException e) {
            System.out.println("Document not found for enquiry number: " + enquiryNumber);
            tempIdenDoc = new HashMap<>();
            tempIdenDoc.put("_id", enquiryNumber);
            tempIdenDoc.put("dtls", rootNode);
            documentService.createDocument(tempIdenDoc);
            System.out.println("New document created for enquiry number: " + enquiryNumber);
        } catch (Exception e) {
            System.err.println("Error while processing document: " + e.getMessage());
            e.printStackTrace();
        }
    }
}



//package in.sis.cqrs.readservice.service;
//
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import org.ektorp.DocumentNotFoundException;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.kafka.annotation.KafkaListener;
//import org.springframework.stereotype.Service;
//import com.fasterxml.jackson.databind.JsonNode;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import in.sis.cqrs.readservice.dto.EnquiryResponse;
//import in.sis.cqrs.readservice.dto.EnquiryResponse.QueryDTO;
//
//@Service
//public class KafkaMessageConsumer {
//
//    @Autowired
//    private ObjectMapper mapper;
//
//    @Autowired
//    private DocumentService documentService;
//
//    @KafkaListener(topics = "loan-enquiry-topic", groupId = "querymodel_group_")
//    public void listen(String message) {
//        try {
//            System.out.println("Received Kafka message: " + message);
//            JsonNode rootNode = mapper.readTree(message);
//
//            JsonNode leadInputsDetails = rootNode.path("data")
//                                                .path("leadInputsDetails");
//            String enquiryNumber = leadInputsDetails.path("enquiry_number")
//                                                   .path("enquiry_number")
//                                                   .asText();
//
//            if (enquiryNumber == null || enquiryNumber.isEmpty()) {
//                System.out.println("Invalid enquiry number received in message.");
//                return;
//            }
//            processEnquiryDocument(enquiryNumber, rootNode);
//        } catch (Exception e) {
//            System.err.println("Error processing message: " + e.getMessage());
//            e.printStackTrace();
//        }
//    }
//
//    private void processEnquiryDocument(String enquiryNumber, JsonNode rootNode) {
//        Map<String, Object> tempIdenDoc;
//        try {
//            tempIdenDoc = documentService.fetchDocument(enquiryNumber);
//
//            if (tempIdenDoc == null || tempIdenDoc.isEmpty()) {
//                System.out.println("Document is empty or not found for enquiry number: " + enquiryNumber);
//            } else {
//                System.out.println("Document contents for enquiry number: " + enquiryNumber + " -> " + tempIdenDoc);
//            }
//
//            EnquiryResponse enquiryResponse = new EnquiryResponse();
//            enquiryResponse.setStatus("1");
//            enquiryResponse.setMessage("Success");
//            enquiryResponse.setImageUpload("Image Upload");
//            enquiryResponse.setLmcApplicability("Image Setup");
//
//            List<QueryDTO> queryDTOList = createQueryDTOList(rootNode);
//            enquiryResponse.setQuery(queryDTOList);
//            System.out.println("Enquiry Response: " + enquiryResponse);
//
//            tempIdenDoc.put("dtls", rootNode);
//            documentService.updateDocument(tempIdenDoc);
//            System.out.println("Document updated successfully for enquiry number: " + enquiryNumber);
//
//        } catch (DocumentNotFoundException e) {
//            System.out.println("Document not found for enquiry number: " + enquiryNumber);
//            tempIdenDoc = new HashMap<>();
//            tempIdenDoc.put("_id", enquiryNumber);
//            tempIdenDoc.put("dtls", rootNode);
//            documentService.createDocument(tempIdenDoc);
//            System.out.println("New document created for enquiry number: " + enquiryNumber);
//        } catch (Exception e) {
//            System.err.println("Error while processing document: " + e.getMessage());
//            e.printStackTrace();
//        }
//    }
//
//    private List<QueryDTO> createQueryDTOList(JsonNode rootNode) {
//        QueryDTO queryDTO = new QueryDTO();
//        
//        queryDTO.setCautionCustomerInd(rootNode.path("data").path("leadInputsDetails").path("caution_customer_ind").asText());
//        queryDTO.setBranchCode(rootNode.path("data").path("leadInputsDetails").path("branch_code").asText());
//        queryDTO.setBranchName(rootNode.path("data").path("leadInputsDetails").path("branch_name").asText());
//        queryDTO.setEnquiryHdrId(rootNode.path("data").path("leadInputsDetails").path("enquiry_hdr_id").asText());
//        queryDTO.setEnquiryDate(rootNode.path("data").path("leadInputsDetails").path("enquiry_date").asText());
//        queryDTO.setContractType(rootNode.path("data").path("leadInputsDetails").path("contract_type").asText());
//        queryDTO.setContractTypeDesc(rootNode.path("data").path("leadInputsDetails").path("contract_type_desc").asText());
//        queryDTO.setAssetClassCode(rootNode.path("data").path("leadInputsDetails").path("asset_class_code").asText());
//        queryDTO.setAssetClassDesc(rootNode.path("data").path("leadInputsDetails").path("asset_class_desc").asText());
//        queryDTO.setSourceOfBusiness(rootNode.path("data").path("leadInputsDetails").path("source_of_business").asText());
//        queryDTO.setPurposeOfLoan(rootNode.path("data").path("leadInputsDetails").path("purpose_of_loan").asText());
//        queryDTO.setPurposeOfLoanDesc(rootNode.path("data").path("leadInputsDetails").path("purpose_of_loan_desc").asText());
//        queryDTO.setSkMarketEmpName(rootNode.path("data").path("leadInputsDetails").path("sk_market_emp_name").asText());
//        queryDTO.setSfMarketEmpCode(rootNode.path("data").path("leadInputsDetails").path("sf_market_emp_code").asText());
//        queryDTO.setLoanAmount(rootNode.path("data").path("leadInputsDetails").path("loan_amount").asText());
//        queryDTO.setEnquiryStatus(rootNode.path("data").path("leadInputsDetails").path("enquiry_status").asText());
//        queryDTO.setEnquiryStatusDesc(rootNode.path("data").path("leadInputsDetails").path("enquiry_status_desc").asText());
//        queryDTO.setRemarks(rootNode.path("data").path("leadInputsDetails").path("remarks").asText());
//        queryDTO.setHunterLogId(rootNode.path("data").path("leadInputsDetails").path("hunter_log_id").asText());
//        queryDTO.setHunterResult(rootNode.path("data").path("leadInputsDetails").path("hunter_result").asText());
//        queryDTO.setHunterResultDesc(rootNode.path("data").path("leadInputsDetails").path("hunter_result_desc").asText());
//        queryDTO.setCreditDecisionElgInd(rootNode.path("data").path("leadInputsDetails").path("credit_decision_elg_ind").asText());
//        queryDTO.setApplicantType(rootNode.path("data").path("leadInputsDetails").path("applicant_type").asText());
//        queryDTO.setConstitutionType(rootNode.path("data").path("leadInputsDetails").path("constitution_type").asText());
//        queryDTO.setCustomerType(rootNode.path("data").path("leadInputsDetails").path("customer_type").asText());
//        queryDTO.setContractNo(rootNode.path("data").path("leadInputsDetails").path("contract_no").asText());
//        queryDTO.setCustomerCode(rootNode.path("data").path("leadInputsDetails").path("customer_code").asText());
//        queryDTO.setCustomerGroupName(rootNode.path("data").path("leadInputsDetails").path("customer_group_name").asText());
//        queryDTO.setCustomerGroupCode(rootNode.path("data").path("leadInputsDetails").path("customer_group_code").asText());
//        queryDTO.setGender(rootNode.path("data").path("leadInputsDetails").path("gender").asText());
//        queryDTO.setApplicantName(rootNode.path("data").path("leadInputsDetails").path("applicant_name").asText());
//        queryDTO.setStreetName(rootNode.path("data").path("leadInputsDetails").path("street_name").asText());
//        queryDTO.setAddrLine1(rootNode.path("data").path("leadInputsDetails").path("addr_line1").asText());
//        queryDTO.setAddrLine2(rootNode.path("data").path("leadInputsDetails").path("addr_line2").asText());
//        queryDTO.setLocRecId(rootNode.path("data").path("leadInputsDetails").path("loc_rec_id").asText());
//        queryDTO.setLocationName(rootNode.path("data").path("leadInputsDetails").path("location_name").asText());
//        queryDTO.setDistrict(rootNode.path("data").path("leadInputsDetails").path("district").asText());
//        queryDTO.setStateName(rootNode.path("data").path("leadInputsDetails").path("state_name").asText());
//        queryDTO.setDob(rootNode.path("data").path("leadInputsDetails").path("dob").asText());
//        queryDTO.setAge(rootNode.path("data").path("leadInputsDetails").path("age").asText());
//        queryDTO.setPan(rootNode.path("data").path("leadInputsDetails").path("pan").asText());
//        queryDTO.setDrivingLicenceNo(rootNode.path("data").path("leadInputsDetails").path("driving_licence_no").asText());
//        queryDTO.setPassportNo(rootNode.path("data").path("leadInputsDetails").path("passport_no").asText());
//        queryDTO.setVoterIdNo(rootNode.path("data").path("leadInputsDetails").path("voter_id_no").asText());
//        queryDTO.setAadhaarNumber(rootNode.path("data").path("leadInputsDetails").path("aadhaar_number").asText());
//        queryDTO.setMobileNo(rootNode.path("data").path("leadInputsDetails").path("mobile_no").asText());
//        queryDTO.setAreaCode(rootNode.path("data").path("leadInputsDetails").path("area_code").asText());
//        queryDTO.setTeleNo(rootNode.path("data").path("leadInputsDetails").path("tele_no").asText());
//        queryDTO.setCibilReqNo(rootNode.path("data").path("leadInputsDetails").path("cibil_req_no").asText());
//        queryDTO.setCibilRefId(rootNode.path("data").path("leadInputsDetails").path("cibil_ref_id").asText());
//        queryDTO.setCibilStatus(rootNode.path("data").path("leadInputsDetails").path("cibil_status").asText());
//        queryDTO.setApplicationNo(rootNode.path("data").path("leadInputsDetails").path("application_no").asText());
//        queryDTO.setHirePeriod(rootNode.path("data").path("leadInputsDetails").path("hire_period").asText());
//        queryDTO.setTitle(rootNode.path("data").path("leadInputsDetails").path("title").asText());
//        queryDTO.setInitialName(rootNode.path("data").path("leadInputsDetails").path("initial_name").asText());
//        queryDTO.setMiddleName(rootNode.path("data").path("leadInputsDetails").path("middle_name").asText());
//        queryDTO.setLastName(rootNode.path("data").path("leadInputsDetails").path("last_name").asText());
//        queryDTO.setAlternateMobileNo(rootNode.path("data").path("leadInputsDetails").path("alternate_mobile_no").asText());
//        queryDTO.setEmailId(rootNode.path("data").path("leadInputsDetails").path("email_id").asText());
//        queryDTO.setMaritalStatus(rootNode.path("data").path("leadInputsDetails").path("marital_status").asText());
//        queryDTO.setEducationQualification(rootNode.path("data").path("leadInputsDetails").path("education_qualification").asText());
//        queryDTO.setOccupation(rootNode.path("data").path("leadInputsDetails").path("occupation").asText());
//        queryDTO.setBusiness(rootNode.path("data").path("leadInputsDetails").path("business").asText());
//        queryDTO.setRelationshipWithCustomer(rootNode.path("data").path("leadInputsDetails").path("relationship_with_customer").asText());
//        queryDTO.setDeviceInd(rootNode.path("data").path("leadInputsDetails").path("device_ind").asText());
//        queryDTO.setAssetMakeCode(rootNode.path("data").path("leadInputsDetails").path("asset_make_code").asText());
//        queryDTO.setAssetMakeDesc(rootNode.path("data").path("leadInputsDetails").path("asset_make_desc").asText());
//        queryDTO.setAssetTypeId(rootNode.path("data").path("leadInputsDetails").path("asset_type_id").asText());
//        queryDTO.setAssetTypeDesc(rootNode.path("data").path("leadInputsDetails").path("asset_type_desc").asText());
//        queryDTO.setMarketValue(rootNode.path("data").path("leadInputsDetails").path("market_value").asText());
//        queryDTO.setModel(rootNode.path("data").path("leadInputsDetails").path("model").asText());
//        queryDTO.setUnits(rootNode.path("data").path("leadInputsDetails").path("units").asText());
//        queryDTO.setOrgBranchCode(rootNode.path("data").path("leadInputsDetails").path("org_branch_code").asText());
//        queryDTO.setOrgMarketEmpCode(rootNode.path("data").path("leadInputsDetails").path("org_market_emp_code").asText());
//        queryDTO.setEnquiryNumber(rootNode.path("data").path("leadInputsDetails").path("enquiry_number").asText());
//        queryDTO.setPincode(rootNode.path("data").path("leadInputsDetails").path("pincode").asText());
//        queryDTO.setAssessmentCriteria(rootNode.path("data").path("leadInputsDetails").path("assessment_criteria").asText());
//        queryDTO.setAssessmentCriteriaDesc(rootNode.path("data").path("leadInputsDetails").path("assessment_criteria_desc").asText());
//        queryDTO.setEmplBusiYrs(rootNode.path("data").path("leadInputsDetails").path("empl_busi_yrs").asText());
//        queryDTO.setNetIncome(rootNode.path("data").path("leadInputsDetails").path("net_income").asText());
//        queryDTO.setCamAssetUsageCode(rootNode.path("data").path("leadInputsDetails").path("cam_asset_usage_code").asText());
//        queryDTO.setCamAssetUsageDesc(rootNode.path("data").path("leadInputsDetails").path("cam_asset_usage_desc").asText());
//        queryDTO.setUsageExpInYrs(rootNode.path("data").path("leadInputsDetails").path("usage_exp_in_yrs").asText());
//        queryDTO.setIrrQuotedToCustomer(rootNode.path("data").path("leadInputsDetails").path("irr_quoted_to_customer").asText());
//        queryDTO.setResiPincode(rootNode.path("data").path("leadInputsDetails").path("resi_pincode").asText());
//        queryDTO.setResiLocationId(rootNode.path("data").path("leadInputsDetails").path("resi_location_id").asText());
//        queryDTO.setResiLocationName(rootNode.path("data").path("leadInputsDetails").path("resi_location_name").asText());
//        queryDTO.setResiLocStabYrs(rootNode.path("data").path("leadInputsDetails").path("resi_loc_stab_yrs").asText());
//        queryDTO.setBranchStage(rootNode.path("data").path("leadInputsDetails").path("branch_stage").asText());
//        queryDTO.setResiDistrict(rootNode.path("data").path("leadInputsDetails").path("resi_district").asText());
//        queryDTO.setResiState(rootNode.path("data").path("leadInputsDetails").path("resi_state").asText());
//        queryDTO.setLmcApplicability(rootNode.path("data").path("leadInputsDetails").path("lmc_applicability").asText());
//
//        return List.of(queryDTO);
//    }
//}


//package in.sis.cqrs.readservice.service;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import org.ektorp.CouchDbConnector;
//import org.ektorp.DocumentNotFoundException;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.kafka.annotation.KafkaListener;
//import org.springframework.stereotype.Service;
//import com.fasterxml.jackson.databind.JsonNode;
//import com.fasterxml.jackson.databind.ObjectMapper;
//
//import in.sis.cqrs.readservice.dto.EnquiryRequest;
//import in.sis.cqrs.readservice.dto.EnquiryResponse;
//
//@Service
//public class KafkaMessageConsumer {
//
//    @Autowired
//    private ObjectMapper mapper;
//
//    @Autowired
//    private DocumentService documentService;
//
//    @Autowired
//    private CouchDbConnector couchDbConnector;
//
////    @KafkaListener(topics = "loan-enquiry-topic", groupId = "querymodel_group_")
//    public void listen(String message) {
//        try {
//            System.out.println("Received Kafka message: " + message);
//            JsonNode rootNode = mapper.readTree(message);
//
//            JsonNode leadInputsDetails = rootNode.path("data").path("leadInputsDetails");
//            String enquiryNumber = leadInputsDetails.path("enquiry_number").path("enquiry_number").asText();
//
//            if (enquiryNumber == null || enquiryNumber.isEmpty()) {
//                System.out.println("Invalid enquiry number received in message.");
//                return;
//            }
//
//            processEnquiryDocument(enquiryNumber, rootNode);
//
//            EnquiryRequest enquiryRequest = mapper.readValue(message, EnquiryRequest.class);
//            EnquiryResponse enquiryResponse = processEnquiryRequest(enquiryRequest);
//            System.out.println("Prepared response: " + enquiryResponse);
//
//        } catch (Exception e) {
//            System.err.println("Error processing message: " + e.getMessage());
//            e.printStackTrace();
//        }
//    }
//
//    private void processEnquiryDocument(String enquiryNumber, JsonNode rootNode) {
//        Map<String, Object> tempIdenDoc;
//        try {
//            tempIdenDoc = documentService.fetchDocument(enquiryNumber);
//
//            if (tempIdenDoc == null || tempIdenDoc.isEmpty()) {
//                System.out.println("Document is empty or not found for enquiry number: " + enquiryNumber);
//            } else {
//                System.out.println("Document contents for enquiry number: " + enquiryNumber + " -> " + tempIdenDoc);
//            }
//
//            tempIdenDoc.put("dtls", rootNode);
//            documentService.updateDocument(tempIdenDoc);
//            System.out.println("Document updated successfully for enquiry number: " + enquiryNumber);
//
//        } catch (DocumentNotFoundException e) {
//            System.out.println("Document not found for enquiry number: " + enquiryNumber);
//            tempIdenDoc = new HashMap<>();
//            tempIdenDoc.put("_id", enquiryNumber);
//            tempIdenDoc.put("dtls", rootNode);
//            documentService.createDocument(tempIdenDoc);
//            System.out.println("New document created for enquiry number: " + enquiryNumber);
//        } catch (Exception e) {
//            System.err.println("Error while processing document: " + e.getMessage());
//            e.printStackTrace();
//        }
//    }
//
//    public EnquiryResponse processEnquiryRequest(EnquiryRequest enquiryRequest) {
//        EnquiryResponse response = new EnquiryResponse();
//        List<EnquiryResponse.QueryDTO> queryList = new ArrayList<>();
//        EnquiryResponse.QueryDTO queryDTO = new EnquiryResponse.QueryDTO();
//
//        try {
//            String enquiryNumber = enquiryRequest.getEnquiryNumber();
//            Map<String, Object> fetchedDocument = fetchDocument(enquiryNumber);
//
//            if (fetchedDocument == null || fetchedDocument.isEmpty()) {
//                response.setStatus("0");
//                response.setMessage("No data found for enquiry number: " + enquiryNumber);
//                return response;
//            }
//
//            JsonNode rootNode = mapper.convertValue(fetchedDocument, JsonNode.class);
//            JsonNode leadInputsDetails = rootNode.path("data").path("leadInputsDetails");
//            JsonNode leadDetails = rootNode.path("data").path("lead_details");
//
//            queryDTO.setEnquiryNumber(enquiryNumber);
//            queryDTO.setCautionCustomerInd(getValueFromLeadDetails(leadInputsDetails, "caution_customer_ind"));
//            queryDTO.setBranchCode(getValueFromLeadDetails(leadInputsDetails, "branch_code"));
//            queryDTO.setBranchName(getValueFromLeadDetails(leadInputsDetails, "branch_name"));
//            queryDTO.setEnquiryHdrId(getValueFromLeadDetails(leadInputsDetails, "enquiry_hdr_id"));
//            queryDTO.setEnquiryDate(getValueFromLeadDetails(leadInputsDetails, "enquiry_date"));
//            queryDTO.setContractType(getValueFromLeadDetails(leadInputsDetails, "contract_type"));
//            queryDTO.setContractTypeDesc(getValueFromLeadDetails(leadInputsDetails, "contract_type_desc"));
//            queryDTO.setAssetClassCode(getValueFromLeadDetails(leadInputsDetails, "asset_class_code"));
//            queryDTO.setAssetClassDesc(getValueFromLeadDetails(leadInputsDetails, "asset_class_desc"));
//            queryDTO.setSourceOfBusiness(getValueFromLeadDetails(leadInputsDetails, "source_of_business"));
//            queryDTO.setPurposeOfLoan(getValueFromLeadDetails(leadInputsDetails, "purpose_of_loan"));
//            queryDTO.setPurposeOfLoanDesc(getValueFromLeadDetails(leadInputsDetails, "purpose_of_loan_desc"));
//            queryDTO.setLoanAmount(getValueFromLeadDetails(leadInputsDetails, "loan_amount"));
//            queryDTO.setEnquiryStatus(getValueFromLeadDetails(leadInputsDetails, "enquiry_status"));
//            queryDTO.setEnquiryStatusDesc(getValueFromLeadDetails(leadInputsDetails, "enquiry_status_desc"));
//            queryDTO.setRemarks(getValueFromLeadDetails(leadInputsDetails, "remarks"));
//            queryDTO.setHunterLogId(getValueFromLeadDetails(leadInputsDetails, "hunter_log_id"));
//            queryDTO.setHunterResult(getValueFromLeadDetails(leadInputsDetails, "hunter_result"));
//            queryDTO.setHunterResultDesc(getValueFromLeadDetails(leadInputsDetails, "hunter_result_desc"));
//            queryDTO.setCreditDecisionElgInd(getValueFromLeadDetails(leadInputsDetails, "credit_decision_elg_ind"));
//            queryDTO.setApplicantType(getValueFromLeadDetails(leadInputsDetails, "applicant_type"));
//            queryDTO.setConstitutionType(getValueFromLeadDetails(leadInputsDetails, "constitution_type"));
//            queryDTO.setCustomerType(getValueFromLeadDetails(leadInputsDetails, "customer_type"));
//
//            if (leadDetails.isArray() && leadDetails.size() > 0) {
//                JsonNode leadDetail = leadDetails.get(0); 
//                queryDTO.setCustomerCode(getValueFromLeadDetails(leadDetail, "customer_code"));
//                queryDTO.setCustomerGroupName(getValueFromLeadDetails(leadDetail, "customer_group_name"));
//                queryDTO.setGender(getValueFromLeadDetails(leadDetail, "gender"));
//                queryDTO.setApplicantName(getValueFromLeadDetails(leadDetail, "applicant_name"));
//                queryDTO.setStreetName(getValueFromLeadDetails(leadDetail, "street_name"));
//                queryDTO.setAddrLine1(getValueFromLeadDetails(leadDetail, "addr_line1"));
//                queryDTO.setAddrLine2(getValueFromLeadDetails(leadDetail, "addr_line2"));
//                queryDTO.setLocRecId(getValueFromLeadDetails(leadDetail, "loc_rec_id"));
//                queryDTO.setLocationName(getValueFromLeadDetails(leadDetail, "location_name"));
//                queryDTO.setDistrict(getValueFromLeadDetails(leadDetail, "district"));
//                queryDTO.setStateName(getValueFromLeadDetails(leadDetail, "state_name"));
//                queryDTO.setDob(getValueFromLeadDetails(leadDetail, "dob"));
//                queryDTO.setAge(getValueFromLeadDetails(leadDetail, "age"));
//                queryDTO.setPan(getValueFromLeadDetails(leadDetail, "pan"));
//                queryDTO.setDrivingLicenceNo(getValueFromLeadDetails(leadDetail, "driving_licence_no"));
//                queryDTO.setPassportNo(getValueFromLeadDetails(leadDetail, "passport_no"));
//                queryDTO.setVoterIdNo(getValueFromLeadDetails(leadDetail, "voter_id_no"));
//                queryDTO.setAadhaarNumber(getValueFromLeadDetails(leadDetail, "aadhaar_number"));
//                queryDTO.setMobileNo(getValueFromLeadDetails(leadDetail, "mobile_no"));
//                queryDTO.setAreaCode(getValueFromLeadDetails(leadDetail, "area_code"));
//                queryDTO.setTeleNo(getValueFromLeadDetails(leadDetail, "tele_no"));
//                queryDTO.setCibilReqNo(getValueFromLeadDetails(leadDetail, "cibil_req_no"));
//                queryDTO.setCibilRefId(getValueFromLeadDetails(leadDetail, "cibil_ref_id"));
//                queryDTO.setCibilStatus(getValueFromLeadDetails(leadDetail, "cibil_status"));
//                queryDTO.setApplicationNo(getValueFromLeadDetails(leadDetail, "application_no"));
//                queryDTO.setHirePeriod(getValueFromLeadDetails(leadDetail, "hire_period"));
//                queryDTO.setTitle(getValueFromLeadDetails(leadDetail, "title"));
//                queryDTO.setInitialName(getValueFromLeadDetails(leadDetail, "initial_name"));
//                queryDTO.setMiddleName(getValueFromLeadDetails(leadDetail, "middle_name"));
//                queryDTO.setLastName(getValueFromLeadDetails(leadDetail, "last_name"));
//                queryDTO.setAlternateMobileNo(getValueFromLeadDetails(leadDetail, "alternate_mobile_no"));
//                queryDTO.setEmailId(getValueFromLeadDetails(leadDetail, "email_id"));
//                queryDTO.setMaritalStatus(getValueFromLeadDetails(leadDetail, "marital_status"));
//                queryDTO.setEducationQualification(getValueFromLeadDetails(leadDetail, "education_qualification"));
//                queryDTO.setOccupation(getValueFromLeadDetails(leadDetail, "occupation"));
//                queryDTO.setBusiness(getValueFromLeadDetails(leadDetail, "business"));
//                queryDTO.setRelationshipWithCustomer(getValueFromLeadDetails(leadDetail, "relationship_with_customer"));
//                queryDTO.setDeviceInd(getValueFromLeadDetails(leadDetail, "device_ind"));
//                queryDTO.setAssetMakeCode(getValueFromLeadDetails(leadDetail, "asset_make_code"));
//                queryDTO.setAssetMakeDesc(getValueFromLeadDetails(leadDetail, "asset_make_desc"));
//                queryDTO.setAssetTypeId(getValueFromLeadDetails(leadDetail, "asset_type_id"));
//                queryDTO.setAssetTypeDesc(getValueFromLeadDetails(leadDetail, "asset_type_desc"));
//                queryDTO.setMarketValue(getValueFromLeadDetails(leadDetail, "market_value"));
//                queryDTO.setModel(getValueFromLeadDetails(leadDetail, "model"));
//                queryDTO.setUnits(getValueFromLeadDetails(leadDetail, "units"));
//            }
//
//            
//            response.setStatus("1");
//            response.setMessage("Success");
//            queryList.add(queryDTO);
//            response.setQuery(queryList);
//            response.setLmcApplicability("YES"); 
//            response.setImageUpload("image_url"); 
//
//        } catch (Exception e) {
//            response.setStatus("0");
//            response.setMessage("Error processing request");
//            e.printStackTrace();
//        }
//
//        return response;
//    }
//
//    private Map<String, Object> fetchDocument(String id) {
//        try {
//            return couchDbConnector.get(Map.class, id);
//        } catch (Exception e) {
//            return null; // Handle error if document is not found
//        }
//    }
//
//    private String getValueFromLeadDetails(JsonNode leadInputsDetails, String fieldName) {
//        return leadInputsDetails.path(fieldName).asText();
//    }
//}
//
//
//
//package in.sis.cqrs.readservice.service;
//
//import java.util.HashMap;
//import java.util.Map;
//import org.ektorp.DocumentNotFoundException;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.kafka.annotation.KafkaListener;
////import org.springframework.kafka.annotation.KafkaListener;
//import org.springframework.stereotype.Service;
//import org.springframework.web.bind.annotation.PostMapping;
//
//import com.fasterxml.jackson.databind.JsonNode;
//import com.fasterxml.jackson.databind.ObjectMapper;
//
//@Service
//public class KafkaMessageConsumer {
//    @Autowired
//    private ObjectMapper mapper;
//
//    @Autowired
//    private DocumentService documentService;
//
//    @KafkaListener(topics = "loan-enquiry-topic", groupId = "querymodel_group_")
////    @PostMapping("/subscribe")
//    public void listen(String message) {
//        try {
//            System.out.println("Received Kafka message: " + message);
//            JsonNode rootNode = mapper.readTree(message);
//            
//            JsonNode leadInputsDetails = rootNode.path("data")
//                                                .path("leadInputsDetails");
//            String enquiryNumber = leadInputsDetails.path("enquiry_number")
//                                                   .path("enquiry_number")
//                                                   .asText();
//            
//            if (enquiryNumber == null || enquiryNumber.isEmpty()) {
//                System.out.println("Invalid enquiry number received in message.");
//                return;
//            }
//            processEnquiryDocument(enquiryNumber, rootNode);
//        } catch (Exception e) {
//            System.err.println("Error processing message: " + e.getMessage());
//            e.printStackTrace();
//        }
//    }
//
//    private void processEnquiryDocument(String enquiryNumber, JsonNode rootNode) {
//        Map<String, Object> tempIdenDoc;
//        try {
//            tempIdenDoc = documentService.fetchDocument(enquiryNumber);
//            
//            if (tempIdenDoc == null || tempIdenDoc.isEmpty()) {
//                System.out.println("Document is empty or not found for enquiry number: " + enquiryNumber);
//            } else {
//                System.out.println("Document contents for enquiry number: " + enquiryNumber + " -> " + tempIdenDoc);
//            }
//            
//            tempIdenDoc.put("dtls", rootNode);
//            documentService.updateDocument(tempIdenDoc);
//            System.out.println("Document updated successfully for enquiry number: " + enquiryNumber);
//        } catch (DocumentNotFoundException e) {
//            System.out.println("Document not found for enquiry number: " + enquiryNumber);
//            tempIdenDoc = new HashMap<>();
//            tempIdenDoc.put("_id", enquiryNumber);
//            tempIdenDoc.put("dtls", rootNode);
//            documentService.createDocument(tempIdenDoc);
//            System.out.println("New document created for enquiry number: " + enquiryNumber);
//        } catch (Exception e) {
//            System.err.println("Error while processing document: " + e.getMessage());
//            e.printStackTrace();
//        }
//    }
//}
