package in.sis.cqrs.readservice.config;

import org.ektorp.CouchDbConnector;
import org.ektorp.CouchDbInstance;
import org.ektorp.http.HttpClient;
import org.ektorp.http.StdHttpClient;
import org.ektorp.impl.StdCouchDbConnector;
import org.ektorp.impl.StdCouchDbInstance;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource(value = { "file:${PROJECT_HOME}/ext_application.properties" })
public class DataSourceConfig {

	// CouchDB
	@Value("${spring.couchdb.url}")
	private String couchDbUrl;

	@Value("${spring.couchdb.database}")
	private String databaseName;

	@Value("${spring.couchdb.username}")
	private String username;

	@Value("${spring.couchdb.password}")
	private String password;

	@Bean
	public CouchDbConnector couchDbConnector() throws Exception {
		HttpClient httpClient = new StdHttpClient.Builder().url(couchDbUrl).username(username).password(password)
				.build();

		CouchDbInstance dbInstance = new StdCouchDbInstance(httpClient);
		return new StdCouchDbConnector(databaseName, dbInstance);
	}
}

