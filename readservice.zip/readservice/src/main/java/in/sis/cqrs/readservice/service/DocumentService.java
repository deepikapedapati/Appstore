package in.sis.cqrs.readservice.service;

import java.util.Map;

import org.ektorp.CouchDbConnector;
import org.ektorp.DocumentNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DocumentService {
    @Autowired
    private CouchDbConnector couchDbConnector;

    @SuppressWarnings("unchecked")
	public Map<String, Object> fetchDocument(String id) throws DocumentNotFoundException {
        return couchDbConnector.get(Map.class, id);
    }

    public void updateDocument(Map<String, Object> document) {
        couchDbConnector.update(document);
    }

    public void createDocument(Map<String, Object> document) {
        couchDbConnector.create(document);
    }
}
