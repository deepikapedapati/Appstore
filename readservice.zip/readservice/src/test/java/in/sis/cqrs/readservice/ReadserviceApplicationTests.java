package in.sis.cqrs.readservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReadserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
